import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../stores/authStore'

export default function Alerts() {
  const api = useAuthStore(s => s.api)
  const user = useAuthStore(s => s.user)
  const [alerts, setAlerts] = useState([])
  useEffect(() => { refresh() }, [])
  async function refresh() { const res = await api().get('/api/alerts'); setAlerts(res.data) }
  async function resolve(id) { await api().post(`/api/alerts/${id}/resolve`); refresh() }
  return (
    <div className="card">
      <h2>Alerts</h2>
      <ul>
        {alerts.map(a => (
          <li key={a._id}>
            {a.type} — {a.item?.name}: {a.message}
            {!a.resolved && (user?.role !== 'staff') && <button style={{ marginLeft: 8 }} onClick={() => resolve(a._id)}>Resolve</button>}
          </li>
        ))}
      </ul>
    </div>
  )
}
