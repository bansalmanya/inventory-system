import React, { useEffect, useState, useRef } from 'react'
import { useAuthStore } from '../stores/authStore'
import { Html5Qrcode } from 'html5-qrcode'

export default function Items() {
  const api = useAuthStore(s => s.api)
  const user = useAuthStore(s => s.user)
  const [items, setItems] = useState([])
  const [form, setForm] = useState({ sku: '', name: '', reorderPoint: 10, targetStock: 50 })
  const [scanning, setScanning] = useState(false)
  const scannerRef = useRef(null)
  const [q, setQ] = useState('')
  const [results, setResults] = useState([])

  useEffect(() => { refresh() }, [])
  async function refresh() { const res = await api().get('/api/inventory/items'); setItems(res.data) }

  useEffect(() => {
    const c = api()
    const t = setTimeout(async () => {
      if (!q) { setResults([]); return }
      try { const r = await c.get('/api/inventory/items/search', { params: { q } }); setResults(r.data) } catch {}
    }, 250)
    return () => clearTimeout(t)
  }, [q])

  async function createItem(e) {
    e.preventDefault()
    await api().post('/api/inventory/items', form)
    setForm({ sku: '', name: '', reorderPoint: 10, targetStock: 50 })
    refresh()
  }

  function startScan() {
    setScanning(true)
    const qr = new Html5Qrcode('qr-region')
    scannerRef.current = qr
    qr.start({ facingMode: 'environment' }, { fps: 10, qrbox: 200 }, (decodedText) => {
      setForm(v => ({ ...v, qrCode: decodedText }))
      stopScan()
    })
  }
  function stopScan() { setScanning(false); scannerRef.current?.stop().then(() => scannerRef.current?.clear()) }

  return (
    <div>
      <h2>Items</h2>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <input placeholder="Search (fuzzy)" value={q} onChange={e => setQ(e.target.value)} />
      </div>
      {q && (
        <div className="card" style={{ marginBottom: 16 }}>
          <strong>Results:</strong>
          <ul>
            {results.map(r => (
              <li key={r._id}>{r.sku} — {r.name} {r.tags?.length ? `(${r.tags.join(', ')})` : ''}</li>
            ))}
          </ul>
        </div>
      )}
      {(user?.role === 'admin' || user?.role === 'manager') ? (
        <form className="card" onSubmit={createItem} style={{ display: 'grid', gap: 8, maxWidth: 520 }}>
          <input placeholder="SKU" value={form.sku} onChange={e => setForm({ ...form, sku: e.target.value })} required />
          <input placeholder="Name" value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} required />
          <input placeholder="Reorder Point" type="number" value={form.reorderPoint} onChange={e => setForm({ ...form, reorderPoint: Number(e.target.value) })} />
          <input placeholder="Target Stock" type="number" value={form.targetStock} onChange={e => setForm({ ...form, targetStock: Number(e.target.value) })} />
          <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
            <input placeholder="QR Code" value={form.qrCode || ''} onChange={e => setForm({ ...form, qrCode: e.target.value })} />
            {!scanning ? <button type="button" onClick={startScan}>Scan QR</button> : <button type="button" onClick={stopScan}>Stop</button>}
          </div>
          <div id="qr-region" style={{ width: 240, height: 240, display: scanning ? 'block' : 'none' }} />
          <button type="submit">Create</button>
        </form>
      ) : (
        <div style={{ margin: '12px 0', opacity: 0.75 }}>Read-only access. Ask an admin/manager for edit rights.</div>
      )}
      <hr />
      <div className="card">
      <table>
        <thead>
          <tr>
            <th align="left">SKU</th>
            <th align="left">Name</th>
            <th align="left">Reorder</th>
            <th align="left">Target</th>
          </tr>
        </thead>
        <tbody>
          {items.map(it => (
            <tr key={it._id}>
              <td>{it.sku}</td>
              <td>{it.name}</td>
              <td>{it.reorderPoint}</td>
              <td>{it.targetStock}</td>
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  )
}


