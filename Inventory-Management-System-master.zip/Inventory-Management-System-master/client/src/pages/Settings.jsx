import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../stores/authStore'
import { useThemeStore } from '../stores/themeStore'

export default function Settings() {
  const api = useAuthStore(s => s.api)
  const theme = useThemeStore(s => s.theme)
  const setTheme = useThemeStore(s => s.setTheme)
  const [hooks, setHooks] = useState([])
  const [form, setForm] = useState({ url: '', event: 'low_stock' })

  useEffect(() => { refresh() }, [])
  async function refresh() { const res = await api().get('/api/webhooks'); setHooks(res.data) }
  async function add(e) { e.preventDefault(); await api().post('/api/webhooks', form); setForm({ url: '', event: 'low_stock' }); refresh() }
  async function remove(id) { await api().delete(`/api/webhooks/${id}`); refresh() }

  return (
    <div className="card">
      <h2>Settings</h2>
      <h3>Theme</h3>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center', marginBottom: 12 }}>
        <label>Mode:</label>
        <select value={theme} onChange={e => setTheme(e.target.value)}>
          <option value="light">Light</option>
          <option value="dark">Dark</option>
        </select>
      </div>
      <h3>Webhooks</h3>
      <form onSubmit={add} style={{ display: 'flex', gap: 8 }}>
        <input placeholder="https://example.com/webhook" value={form.url} onChange={e => setForm({ ...form, url: e.target.value })} required />
        <select value={form.event} onChange={e => setForm({ ...form, event: e.target.value })}>
          <option value="low_stock">Low Stock</option>
          <option value="expiry_soon">Expiry Soon</option>
          <option value="transaction">Transaction</option>
        </select>
        <button type="submit">Add</button>
      </form>
      <ul>
        {hooks.map(h => (
          <li key={h.id}>{h.event} → {h.url} <button onClick={() => remove(h.id)}>Remove</button></li>
        ))}
      </ul>
    </div>
  )
}


