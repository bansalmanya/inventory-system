import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../stores/authStore'

export default function Transactions() {
  const api = useAuthStore(s => s.api)
  const user = useAuthStore(s => s.user)
  const [items, setItems] = useState([])
  const [locations, setLocations] = useState([])
  const [txs, setTxs] = useState([])
  const [outForm, setOutForm] = useState({ item: '', quantity: 1, fromLocation: '', note: '' })
  const [inForm, setInForm] = useState({ item: '', quantity: 1, toLocation: '', note: '' })

  useEffect(() => { refresh() }, [])
  async function refresh() {
    const c = api()
    const [i, l, t] = await Promise.all([
      c.get('/api/inventory/items'),
      c.get('/api/inventory/locations'),
      c.get('/api/transactions')
    ])
    setItems(i.data); setLocations(l.data); setTxs(t.data)
  }

  async function submitOut(e) {
    e.preventDefault()
    await api().post('/api/transactions/out', outForm)
    setOutForm({ item: '', quantity: 1, fromLocation: '', note: '' })
    refresh()
  }
  async function submitIn(e) {
    e.preventDefault()
    await api().post('/api/transactions/in', inForm)
    setInForm({ item: '', quantity: 1, toLocation: '', note: '' })
    refresh()
  }

  return (
    <div>
      <h2>Transactions</h2>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 24 }}>
        {(user?.role === 'viewer') ? (
          <div className="card">Read-only access.</div>
        ) : (
        <form className="card" onSubmit={submitOut}>
          <h3>Stock Out</h3>
          <select value={outForm.item} onChange={e => setOutForm({ ...outForm, item: e.target.value })} required>
            <option value="">Item</option>
            {items.map(i => <option key={i._id} value={i._id}>{i.name}</option>)}
          </select>
          <input type="number" value={outForm.quantity} onChange={e => setOutForm({ ...outForm, quantity: Number(e.target.value) })} min={1} />
          <select value={outForm.fromLocation} onChange={e => setOutForm({ ...outForm, fromLocation: e.target.value })} required>
            <option value="">From location</option>
            {locations.map(l => <option key={l._id} value={l._id}>{l.name}</option>)}
          </select>
          <input placeholder="Note" value={outForm.note} onChange={e => setOutForm({ ...outForm, note: e.target.value })} />
          <button type="submit">Submit</button>
        </form>
        )}

        {(user?.role === 'viewer') ? (
          <div />
        ) : (
        <form className="card" onSubmit={submitIn}>
          <h3>Stock In</h3>
          <select value={inForm.item} onChange={e => setInForm({ ...inForm, item: e.target.value })} required>
            <option value="">Item</option>
            {items.map(i => <option key={i._id} value={i._id}>{i.name}</option>)}
          </select>
          <input type="number" value={inForm.quantity} onChange={e => setInForm({ ...inForm, quantity: Number(e.target.value) })} min={1} />
          <select value={inForm.toLocation} onChange={e => setInForm({ ...inForm, toLocation: e.target.value })} required>
            <option value="">To location</option>
            {locations.map(l => <option key={l._id} value={l._id}>{l.name}</option>)}
          </select>
          <input placeholder="Note" value={inForm.note} onChange={e => setInForm({ ...inForm, note: e.target.value })} />
          <button type="submit">Submit</button>
        </form>
        )}
      </div>
      <hr />
      <h3>Recent</h3>
      <ul>
        {txs.map(tx => (
          <li key={tx._id}>[{tx.type}] {tx.item?.name || tx.item} x{tx.quantity} {tx.fromLocation?.name ? `from ${tx.fromLocation?.name}` : ''} {tx.toLocation?.name ? `to ${tx.toLocation?.name}` : ''} — {new Date(tx.createdAt).toLocaleString()}</li>
        ))}
      </ul>
    </div>
  )
}
