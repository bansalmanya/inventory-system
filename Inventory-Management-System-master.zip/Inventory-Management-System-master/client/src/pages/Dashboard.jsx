import React, { useEffect, useState } from 'react'
import { useAuthStore } from '../stores/authStore'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, BarChart, Bar } from 'recharts'

export default function Dashboard() {
  const api = useAuthStore(s => s.api)
  const [low, setLow] = useState([])
  const [expiry, setExpiry] = useState([])
  const [forecast, setForecast] = useState([])
  const [trends, setTrends] = useState([])
  const [movement, setMovement] = useState([])

  useEffect(() => {
    const c = api()
    Promise.all([
      c.get('/api/analytics/low-stock'),
      c.get('/api/analytics/expiry-soon'),
      c.get('/api/analytics/forecast'),
      c.get('/api/analytics/trends'),
      c.get('/api/analytics/movement')
    ]).then(([a, b, f, t, m]) => { setLow(a.data); setExpiry(b.data); setForecast(f.data); setTrends(t.data); setMovement(m.data) })
  }, [])

  return (
    <div>
      <h2>Dashboard</h2>
      <section className="card" style={{ marginBottom: 24 }}>
        <h3>Inventory Trends (14d)</h3>
        <div style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={trends} margin={{ left: 12, right: 12 }}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="in" stroke="#22c55e" name="In" />
              <Line type="monotone" dataKey="out" stroke="#ef4444" name="Out" />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="card" style={{ marginBottom: 24 }}>
        <h3>Fast/Slow Movers (30d)</h3>
        <div style={{ height: 260 }}>
          <ResponsiveContainer width="100%" height="100%">
            <BarChart data={movement.slice(0, 10).map(x => ({ name: x.item.name, total: x.totalOut }))}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="name" interval={0} angle={-20} textAnchor="end" height={80} />
              <YAxis />
              <Tooltip />
              <Bar dataKey="total" fill="#3b82f6" name="Out qty" />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </section>
      <section className="card">
        <h3>Low Stock</h3>
        <ul>
          {low.map(x => (
            <li key={x.item._id}>{x.item.name} — {x.total} / RP {x.item.reorderPoint}</li>
          ))}
        </ul>
      </section>
      <section className="card">
        <h3>Expiring Soon (14 days)</h3>
        <ul>
          {expiry.map(b => (
            <li key={b._id}>{b.item.name} — {b.quantity} at {b.location.name} exp {new Date(b.expiryDate).toLocaleDateString()}</li>
          ))}
        </ul>
      </section>
      <section className="card">
        <h3>Forecast</h3>
        <ul>
          {forecast.map(f => (
            <li key={f.item._id}>{f.item.name}: stock {f.stock}, avg/day {f.avgDailyOut.toFixed(2)}, days left {Number.isFinite(f.daysLeft) ? f.daysLeft.toFixed(1) : '∞'}</li>
          ))}
        </ul>
      </section>
    </div>
  )
}
