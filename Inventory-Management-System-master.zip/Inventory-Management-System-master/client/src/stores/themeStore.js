import { create } from 'zustand'

const saved = localStorage.getItem('ims_theme') || 'light'

export const useThemeStore = create((set) => ({
  theme: saved,
  setTheme: (t) => { set({ theme: t }); localStorage.setItem('ims_theme', t) },
  toggle: () => set((s) => { const t = s.theme === 'light' ? 'dark' : 'light'; localStorage.setItem('ims_theme', t); return { theme: t } })
}))
