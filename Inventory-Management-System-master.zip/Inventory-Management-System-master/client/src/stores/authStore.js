import { create } from 'zustand'
import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:4001'

export const useAuthStore = create((set, get) => ({
  token: localStorage.getItem('ims_token') || '',
  user: JSON.parse(localStorage.getItem('ims_user') || 'null'),
  async login(email, password) {
    const res = await axios.post(`${API_BASE}/api/auth/login`, { email, password })
    set({ token: res.data.token, user: res.data.user })
    localStorage.setItem('ims_token', res.data.token)
    localStorage.setItem('ims_user', JSON.stringify(res.data.user))
  },
  logout() {
    set({ token: '', user: null })
    localStorage.removeItem('ims_token')
    localStorage.removeItem('ims_user')
  },
  api() {
    const token = get().token
    const instance = axios.create({ baseURL: API_BASE, headers: token ? { Authorization: `Bearer ${token}` } : {} })
    return instance
  }
}))
