import React from 'react'
import { Routes, Route, Navigate, Link, useLocation } from 'react-router-dom'
import { useAuthStore } from './stores/authStore'
import Dashboard from './pages/Dashboard'
import Login from './pages/Login'
import Items from './pages/Items'
import Transactions from './pages/Transactions'
import Alerts from './pages/Alerts'
import Settings from './pages/Settings'
import { useThemeStore } from './stores/themeStore'

function RequireAuth({ children }) {
  const token = useAuthStore(s => s.token)
  const location = useLocation()
  if (!token) return <Navigate to="/login" state={{ from: location }} replace />
  return children
}

export default function App() {
  const theme = useThemeStore(s => s.theme)
  const logout = useAuthStore(s => s.logout)
  const user = useAuthStore(s => s.user)
  return (
    <div data-theme={theme}>
      <header className="topbar">
        <strong>IMS</strong>
        <Link to="/">Dashboard</Link>
        <Link to="/items">Items</Link>
        <Link to="/transactions">Transactions</Link>
        <Link to="/alerts">Alerts</Link>
        <Link to="/settings">Settings</Link>
        <div className="spacer">
          {user ? (
            <>
              <span style={{ marginRight: 8 }} className="muted">{user.name} ({user.role})</span>
              <button onClick={logout}>Logout</button>
            </>
          ) : (
            <Link to="/login">Login</Link>
          )}
        </div>
      </header>
      <main>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<RequireAuth><Dashboard /></RequireAuth>} />
          <Route path="/items" element={<RequireAuth><Items /></RequireAuth>} />
          <Route path="/transactions" element={<RequireAuth><Transactions /></RequireAuth>} />
          <Route path="/alerts" element={<RequireAuth><Alerts /></RequireAuth>} />
          <Route path="/settings" element={<RequireAuth><Settings /></RequireAuth>} />
        </Routes>
      </main>
    </div>
  )
}


