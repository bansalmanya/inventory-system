# Inventory Management System (React + Node + MongoDB)

A unique, modern IMS with QR code support, multi-location stock, FEFO batch handling, analytics (low stock, expiry, simple forecast), alerts, and webhooks.

## Features
- Auth with JWT and role-based access: admin, manager, staff
- Items with SKU, QR/barcode, reorder point/target stock, attributes
- Multi-location inventory via batches with optional expiry/lot and FEFO selection
- Transactions: stock-in, stock-out, transfer, adjustment (out-of-box: in/out/transfer)
- Analytics: low stock, expiring soon (14 days), simple forecast from last 30 days
- Alerts: list + resolve; low stock/expiry hooks ready
- Webhooks: register endpoints per event with HMAC signature header `X-IMS-Signature`
- QR code item capture in the UI using camera

## Tech
- Server: Node.js, Express, MongoDB (Mongoose), Joi, Helmet, Rate limiting, JWT
- Client: React (Vite), React Router, Zustand, Axios, html5-qrcode

## Getting Started

### Prerequisites
- Node.js 18+
- MongoDB running locally (or Atlas URI)

### Setup

1) Install dependencies
```bash
cd server && npm install
cd ../client && npm install
```

2) Configure environment (server)
Create `server/.env` with:
```bash
NODE_ENV=development
PORT=4000
MONGODB_URI=mongodb://127.0.0.1:27017/ims_dev
JWT_SECRET=change-me
JWT_EXPIRES_IN=7d
CORS_ORIGIN=http://localhost:5173
WEBHOOK_SECRET=whsec_change_me
SMTP_HOST=
SMTP_PORT=587
SMTP_USER=
SMTP_PASS=
```

3) Seed admin and sample data
```bash
cd server
npm run seed
```
Credentials: `admin@example.com` / `admin123`

4) Run
```bash
cd server
npm run dev
# in another terminal
cd client
npm run dev
```

Open `http://localhost:5173`

## API Highlights
- Auth: `POST /api/auth/register`, `POST /api/auth/login`
- Items: `GET/POST/PUT/DELETE /api/inventory/items`
- Stock per item: `GET /api/inventory/stock/:itemId`
- Locations: `GET/POST /api/inventory/locations`
- Transactions: `GET /api/transactions`, `POST /api/transactions/in|out|transfer`
- Analytics: `GET /api/analytics/low-stock|expiry-soon|forecast`
- Alerts: `GET /api/alerts`, `POST /api/alerts/:id/resolve`
- Webhooks: `GET/POST/DELETE /api/webhooks` (admin/manager)

## Ideas to Extend
- CSV import/export for items and transactions
- Email notifications via SMTP for low stock and expiry
- PWA offline scanning and sync
- Supplier PO generation and status tracking
- Attachment uploads and audit logs

## License
MIT