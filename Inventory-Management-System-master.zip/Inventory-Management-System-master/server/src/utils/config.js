const dotenv = require('dotenv');

function loadConfig() {
  dotenv.config();
  return {
    NODE_ENV: process.env.NODE_ENV || 'development',
    PORT: process.env.PORT || 4000,
    MONGODB_URI: process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/ims_dev',
    JWT_SECRET: process.env.JWT_SECRET || 'change-me-in-production',
    JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN || '7d',
    CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173',
    WEBHOOK_SECRET: process.env.WEBHOOK_SECRET || 'whsec_dev',
    SMTP_HOST: process.env.SMTP_HOST || '',
    SMTP_PORT: Number(process.env.SMTP_PORT || 587),
    SMTP_USER: process.env.SMTP_USER || '',
    SMTP_PASS: process.env.SMTP_PASS || ''
  };
}

module.exports = { loadConfig };


