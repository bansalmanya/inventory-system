const mongoose = require('mongoose');

async function connectToDatabase(uri) {
  if (!uri) throw new Error('MONGODB_URI is not defined');
  await mongoose.connect(uri, {
    autoIndex: true
  });
  console.log('Connected to MongoDB');
}

module.exports = { connectToDatabase };


