const jwt = require('jsonwebtoken');
const { loadConfig } = require('../utils/config');

function authenticate(req, res, next) {
  const config = loadConfig();
  const authHeader = req.headers.authorization || '';
  const token = authHeader.startsWith('Bearer ') ? authHeader.slice(7) : null;
  if (!token) return res.status(401).json({ error: { message: 'Unauthorized' } });
  try {
    const payload = jwt.verify(token, config.JWT_SECRET);
    req.user = payload;
    next();
  } catch (e) {
    return res.status(401).json({ error: { message: 'Invalid token' } });
  }
}

function requireRole(roles) {
  const required = Array.isArray(roles) ? roles : [roles];
  return (req, res, next) => {
    if (!req.user) return res.status(401).json({ error: { message: 'Unauthorized' } });
    if (!required.includes(req.user.role)) {
      return res.status(403).json({ error: { message: 'Forbidden' } });
    }
    next();
  };
}

module.exports = { authenticate, requireRole };


