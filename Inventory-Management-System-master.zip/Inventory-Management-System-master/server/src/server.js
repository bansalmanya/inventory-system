const app = require('./app');
const { connectToDatabase } = require('./utils/db');
const { loadConfig } = require('./utils/config');

async function start() {
  const config = loadConfig();
  await connectToDatabase(config.MONGODB_URI);

  const port = config.PORT || 4000;
  app.listen(port, () => {
    console.log(`IMS server listening on port ${port}`);
  });
}

start().catch((err) => {
  console.error('Fatal startup error:', err);
  process.exit(1);
});
