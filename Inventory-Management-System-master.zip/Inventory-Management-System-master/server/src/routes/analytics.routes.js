const router = require('express').Router();
const dayjs = require('dayjs');
const { authenticate } = require('../middleware/auth');
const Item = require('../models/Item');
const Batch = require('../models/Batch');
const Transaction = require('../models/Transaction');

router.use(authenticate);

router.get('/low-stock', async (_req, res) => {
  const items = await Item.find();
  const results = [];
  for (const item of items) {
    const agg = await Batch.aggregate([
      { $match: { item: item._id } },
      { $group: { _id: '$item', total: { $sum: '$quantity' } } }
    ]);
    const total = agg[0]?.total || 0;
    if (total <= item.reorderPoint) {
      results.push({ item, total });
    }
  }
  res.json(results);
});

router.get('/expiry-soon', async (_req, res) => {
  const soon = dayjs().add(14, 'day').toDate();
  const batches = await Batch.find({ expiryDate: { $ne: null, $lte: soon } }).populate('item location');
  res.json(batches);
});

router.get('/forecast', async (_req, res) => {
  const windowDays = 30;
  const since = dayjs().subtract(windowDays, 'day').toDate();
  const txs = await Transaction.aggregate([
    { $match: { type: 'out', createdAt: { $gte: since } } },
    { $group: { _id: '$item', totalOut: { $sum: '$quantity' } } }
  ]);
  const forecasts = [];
  for (const t of txs) {
    const item = await Item.findById(t._id);
    if (!item) continue;
    const avgDailyOut = t.totalOut / windowDays;
    const stockAgg = await Batch.aggregate([{ $match: { item: item._id } }, { $group: { _id: '$item', total: { $sum: '$quantity' } } }]);
    const stock = stockAgg[0]?.total || 0;
    const daysLeft = avgDailyOut ? stock / avgDailyOut : Infinity;
    forecasts.push({ item, stock, avgDailyOut, daysLeft });
  }
  res.json(forecasts);
});

// Movement: fast/slow movers based on last 30 days 'out' totals
router.get('/movement', async (_req, res) => {
  const since = dayjs().subtract(30, 'day').toDate();
  const agg = await Transaction.aggregate([
    { $match: { type: 'out', createdAt: { $gte: since } } },
    { $group: { _id: '$item', totalOut: { $sum: '$quantity' } } },
    { $sort: { totalOut: -1 } }
  ]);
  const withItems = await Promise.all(
    agg.map(async a => ({ item: await Item.findById(a._id), totalOut: a.totalOut }))
  );
  res.json(withItems.filter(x => x.item));
});

// Trends: daily in/out totals for last 14 days
router.get('/trends', async (_req, res) => {
  const days = 14;
  const since = dayjs().subtract(days, 'day').startOf('day').toDate();
  const agg = await Transaction.aggregate([
    { $match: { createdAt: { $gte: since } } },
    { $project: { day: { $dateToString: { date: '$createdAt', format: '%Y-%m-%d' } }, type: 1, quantity: 1 } },
    { $group: { _id: { day: '$day', type: '$type' }, qty: { $sum: '$quantity' } } }
  ]);
  const byDay = {};
  for (let i = days - 1; i >= 0; i--) {
    const d = dayjs().subtract(i, 'day').format('YYYY-MM-DD');
    byDay[d] = { day: d, in: 0, out: 0, transfer: 0, adjustment: 0 };
  }
  for (const a of agg) {
    const d = a._id.day;
    if (!byDay[d]) continue;
    byDay[d][a._id.type] = a.qty;
  }
  res.json(Object.values(byDay));
});

module.exports = router;



