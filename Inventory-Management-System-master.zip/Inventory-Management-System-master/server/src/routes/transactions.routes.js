const router = require('express').Router();
const Joi = require('joi');
const dayjs = require('dayjs');
const { authenticate, requireRole } = require('../middleware/auth');
const Batch = require('../models/Batch');
const Transaction = require('../models/Transaction');

router.use(authenticate);

router.get('/', async (_req, res) => {
  const txs = await Transaction.find().sort({ createdAt: -1 }).limit(200).populate('item fromLocation toLocation');
  res.json(txs);
});

router.post('/in', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({ item: Joi.string().required(), quantity: Joi.number().positive().required(), toLocation: Joi.string().required(), lotNumber: Joi.string().allow(''), expiryDate: Joi.date().optional(), costPerUnit: Joi.number().min(0).default(0), note: Joi.string().allow('') });
    const payload = await schema.validateAsync(req.body);
    const batch = await Batch.create({ item: payload.item, location: payload.toLocation, quantity: payload.quantity, lotNumber: payload.lotNumber, expiryDate: payload.expiryDate, costPerUnit: payload.costPerUnit });
    const tx = await Transaction.create({ type: 'in', item: payload.item, quantity: payload.quantity, toLocation: payload.toLocation, note: payload.note, userId: req.user.sub });
    res.status(201).json({ batch, tx });
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.post('/out', requireRole(['admin', 'manager', 'staff']), async (req, res, next) => {
  try {
    const schema = Joi.object({ item: Joi.string().required(), quantity: Joi.number().positive().required(), fromLocation: Joi.string().required(), note: Joi.string().allow('') });
    const { item, quantity, fromLocation, note } = await schema.validateAsync(req.body);

    let remaining = quantity;
    const batches = await Batch.find({ item, location: fromLocation }).sort({ expiryDate: 1, createdAt: 1 });
    const updates = [];
    for (const b of batches) {
      if (remaining <= 0) break;
      const take = Math.min(b.quantity, remaining);
      b.quantity -= take;
      remaining -= take;
      updates.push(b.save());
    }
    await Promise.all(updates);
    await Batch.deleteMany({ item, location: fromLocation, quantity: { $lte: 0 } });
    const tx = await Transaction.create({ type: 'out', item, quantity, fromLocation, note, userId: req.user.sub });
    if (remaining > 0) {
      return res.status(409).json({ error: { message: `Insufficient stock, short by ${remaining}` } });
    }
    res.status(201).json({ ok: true, tx });
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.post('/transfer', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({ item: Joi.string().required(), quantity: Joi.number().positive().required(), fromLocation: Joi.string().required(), toLocation: Joi.string().required(), note: Joi.string().allow('') });
    const { item, quantity, fromLocation, toLocation, note } = await schema.validateAsync(req.body);

    let remaining = quantity;
    const sourceBatches = await Batch.find({ item, location: fromLocation }).sort({ expiryDate: 1, createdAt: 1 });
    const writes = [];
    for (const b of sourceBatches) {
      if (remaining <= 0) break;
      const move = Math.min(b.quantity, remaining);
      b.quantity -= move;
      remaining -= move;
      writes.push(b.save());
      writes.push(Batch.create({ item, location: toLocation, quantity: move, lotNumber: b.lotNumber, expiryDate: b.expiryDate, costPerUnit: b.costPerUnit }));
    }
    await Promise.all(writes);
    await Batch.deleteMany({ item, location: fromLocation, quantity: { $lte: 0 } });
    const tx = await Transaction.create({ type: 'transfer', item, quantity, fromLocation, toLocation, note, userId: req.user.sub });
    if (remaining > 0) return res.status(409).json({ error: { message: `Insufficient stock to transfer, short by ${remaining}` } });
    res.status(201).json({ ok: true, tx });
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

module.exports = router;


