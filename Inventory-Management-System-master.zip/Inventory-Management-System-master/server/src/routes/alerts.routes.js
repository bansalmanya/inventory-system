const router = require('express').Router();
const { authenticate, requireRole } = require('../middleware/auth');
const Alert = require('../models/Alert');

router.use(authenticate);

router.get('/', async (_req, res) => {
  const alerts = await Alert.find().sort({ createdAt: -1 }).populate('item');
  res.json(alerts);
});

router.post('/:id/resolve', requireRole(['admin', 'manager']), async (req, res) => {
  const alert = await Alert.findByIdAndUpdate(req.params.id, { resolved: true }, { new: true });
  res.json(alert);
});

module.exports = router;


