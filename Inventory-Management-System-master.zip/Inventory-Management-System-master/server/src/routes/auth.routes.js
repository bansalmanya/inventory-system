const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const Joi = require('joi');
const User = require('../models/User');
const { loadConfig } = require('../utils/config');

router.post('/register', async (req, res, next) => {
  try {
    const schema = Joi.object({
      email: Joi.string().email().required(),
      name: Joi.string().min(2).required(),
      password: Joi.string().min(6).required(),
      role: Joi.string().valid('admin', 'manager', 'staff').default('staff')
    });
    const payload = await schema.validateAsync(req.body);
    const existing = await User.findOne({ email: payload.email });
    if (existing) return res.status(409).json({ error: { message: 'Email already registered' } });
    const passwordHash = await bcrypt.hash(payload.password, 10);
    const user = await User.create({ email: payload.email, name: payload.name, role: payload.role, passwordHash });
    res.status(201).json({ id: user.id, email: user.email, name: user.name, role: user.role });
  } catch (e) {
    if (e.isJoi) e.status = 400;
    next(e);
  }
});

router.post('/login', async (req, res, next) => {
  try {
    const schema = Joi.object({ email: Joi.string().email().required(), password: Joi.string().required() });
    const { email, password } = await schema.validateAsync(req.body);
    const user = await User.findOne({ email });
    if (!user) return res.status(401).json({ error: { message: 'Invalid credentials' } });
    const ok = await user.verifyPassword(password);
    if (!ok) return res.status(401).json({ error: { message: 'Invalid credentials' } });
    const config = loadConfig();
    const token = jwt.sign({ sub: user.id, email: user.email, role: user.role, name: user.name }, config.JWT_SECRET, { expiresIn: config.JWT_EXPIRES_IN });
    res.json({ token, user: { id: user.id, email: user.email, name: user.name, role: user.role } });
  } catch (e) {
    if (e.isJoi) e.status = 400;
    next(e);
  }
});

module.exports = router;


