const router = require('express').Router();
const Joi = require('joi');
const { authenticate, requireRole } = require('../middleware/auth');
const Item = require('../models/Item');
const Batch = require('../models/Batch');
const Location = require('../models/Location');

router.use(authenticate);

router.get('/items', async (_req, res) => {
  const items = await Item.find().sort({ createdAt: -1 });
  res.json(items);
});

// simple fuzzy search by name/sku/tags
router.get('/items/search', async (req, res) => {
  const q = (req.query.q || '').toString().trim();
  if (!q) return res.json([]);
  const rx = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
  const items = await Item.find({ $or: [{ name: rx }, { sku: rx }, { tags: rx }] }).limit(50);
  res.json(items);
});

router.post('/items', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({
      sku: Joi.string().required(),
      name: Joi.string().required(),
      description: Joi.string().allow(''),
      category: Joi.string().allow(''),
      unit: Joi.string().default('pcs'),
      reorderPoint: Joi.number().min(0).default(10),
      targetStock: Joi.number().min(0).default(50),
      barcode: Joi.string().allow(''),
      qrCode: Joi.string().allow(''),
      attributes: Joi.object().unknown(true)
    });
    const payload = await schema.validateAsync(req.body);
    // rule-based auto-tagging
    const baseText = `${payload.name} ${payload.description || ''} ${payload.category || ''}`.toLowerCase();
    const tagRules = [
      { tag: 'electronics', words: ['adapter', 'cable', 'charger', 'laptop', 'phone'] },
      { tag: 'fragile', words: ['glass', 'ceramic', 'fragile'] },
      { tag: 'consumable', words: ['soap', 'sanitizer', 'paper', 'ink'] },
      { tag: 'perishable', words: ['milk', 'meat', 'vegetable', 'fruit'] },
    ];
    const tags = [];
    for (const rule of tagRules) {
      if (rule.words.some(w => baseText.includes(w))) tags.push(rule.tag);
    }
    const item = await Item.create({ ...payload, tags: Array.from(new Set(tags)) });
    res.status(201).json(item);
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.put('/items/:id', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({
      name: Joi.string(),
      description: Joi.string().allow(''),
      category: Joi.string().allow(''),
      unit: Joi.string(),
      reorderPoint: Joi.number().min(0),
      targetStock: Joi.number().min(0),
      barcode: Joi.string().allow(''),
      qrCode: Joi.string().allow(''),
      attributes: Joi.object().unknown(true)
    });
    const payload = await schema.validateAsync(req.body);
    // update tags when name/description/category change
    let tagsUpdate = {};
    if (payload.name || payload.description || payload.category) {
      const baseText = `${payload.name || ''} ${payload.description || ''} ${payload.category || ''}`.toLowerCase();
      const tagRules = [
        { tag: 'electronics', words: ['adapter', 'cable', 'charger', 'laptop', 'phone'] },
        { tag: 'fragile', words: ['glass', 'ceramic', 'fragile'] },
        { tag: 'consumable', words: ['soap', 'sanitizer', 'paper', 'ink'] },
        { tag: 'perishable', words: ['milk', 'meat', 'vegetable', 'fruit'] },
      ];
      const tags = [];
      for (const rule of tagRules) if (rule.words.some(w => baseText.includes(w))) tags.push(rule.tag);
      tagsUpdate = { tags: Array.from(new Set(tags)) };
    }
    const item = await Item.findByIdAndUpdate(req.params.id, { ...payload, ...tagsUpdate }, { new: true });
    res.json(item);
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.delete('/items/:id', requireRole(['admin']), async (req, res) => {
  await Item.findByIdAndDelete(req.params.id);
  await Batch.deleteMany({ item: req.params.id });
  res.status(204).end();
});

router.get('/locations', async (_req, res) => {
  const locations = await Location.find().sort({ createdAt: -1 });
  res.json(locations);
});

router.post('/locations', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({ code: Joi.string().required(), name: Joi.string().required(), type: Joi.string().valid('warehouse', 'store', 'bin').default('warehouse'), address: Joi.string().allow('') });
    const payload = await schema.validateAsync(req.body);
    const loc = await Location.create(payload);
    res.status(201).json(loc);
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.get('/stock/:itemId', async (req, res) => {
  const batches = await Batch.find({ item: req.params.itemId }).populate('location');
  const total = batches.reduce((sum, b) => sum + b.quantity, 0);
  res.json({ total, batches });
});

module.exports = router;


