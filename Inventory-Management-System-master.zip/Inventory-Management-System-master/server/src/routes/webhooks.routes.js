const router = require('express').Router();
const crypto = require('crypto');
const Joi = require('joi');
const { authenticate, requireRole } = require('../middleware/auth');
const { loadConfig } = require('../utils/config');

const webhooks = new Map();

router.use(authenticate);

router.get('/', requireRole(['admin', 'manager']), (_req, res) => {
  res.json(Array.from(webhooks.values()));
});

router.post('/', requireRole(['admin', 'manager']), async (req, res, next) => {
  try {
    const schema = Joi.object({ url: Joi.string().uri().required(), event: Joi.string().valid('low_stock', 'expiry_soon', 'transaction').required() });
    const payload = await schema.validateAsync(req.body);
    const id = crypto.randomUUID();
    webhooks.set(id, { id, ...payload, createdAt: new Date() });
    res.status(201).json(webhooks.get(id));
  } catch (e) { if (e.isJoi) e.status = 400; next(e); }
});

router.delete('/:id', requireRole(['admin', 'manager']), (req, res) => {
  webhooks.delete(req.params.id);
  res.status(204).end();
});

function dispatchWebhook(event, data) {
  const config = loadConfig();
  const secret = config.WEBHOOK_SECRET;
  const body = JSON.stringify({ event, data, sentAt: new Date().toISOString() });
  for (const wh of webhooks.values()) {
    if (wh.event !== event) continue;
    const signature = crypto.createHmac('sha256', secret).update(body).digest('hex');
    fetch(wh.url, { method: 'POST', headers: { 'Content-Type': 'application/json', 'X-IMS-Signature': signature }, body }).catch(() => {});
  }
}

module.exports = router;
module.exports.dispatchWebhook = dispatchWebhook;


