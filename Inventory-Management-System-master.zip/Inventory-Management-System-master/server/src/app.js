const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');
const { loadConfig } = require('./utils/config');
const { errorHandler } = require('./middleware/errorHandler');

const authRoutes = require('./routes/auth.routes');
const inventoryRoutes = require('./routes/inventory.routes');
const transactionsRoutes = require('./routes/transactions.routes');
const analyticsRoutes = require('./routes/analytics.routes');
const alertsRoutes = require('./routes/alerts.routes');
const webhooksRoutes = require('./routes/webhooks.routes');

const app = express();
const config = loadConfig();

app.set('trust proxy', 1);
app.use(helmet());
app.use(cors({
  origin: config.CORS_ORIGIN || true,
  credentials: true
}));
app.use(express.json({ limit: '1mb' }));
app.use(cookieParser());
app.use(morgan('dev'));

const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000
});
app.use(limiter);

app.get('/health', (_req, res) => {
  res.json({ status: 'ok', service: 'ims-server' });
});

app.use('/api/auth', authRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/transactions', transactionsRoutes);
app.use('/api/analytics', analyticsRoutes);
app.use('/api/alerts', alertsRoutes);
app.use('/api/webhooks', webhooksRoutes);

app.use(errorHandler);

module.exports = app;


