const mongoose = require('mongoose');

const TransactionSchema = new mongoose.Schema(
  {
    type: { type: String, enum: ['in', 'out', 'transfer', 'adjustment'], required: true },
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
    quantity: { type: Number, required: true },
    fromLocation: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
    toLocation: { type: mongoose.Schema.Types.ObjectId, ref: 'Location' },
    note: { type: String },
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User' }
  },
  { timestamps: true }
);

const Transaction = mongoose.model('Transaction', TransactionSchema);
module.exports = Transaction;


