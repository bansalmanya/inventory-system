const mongoose = require('mongoose');

const LocationSchema = new mongoose.Schema(
  {
    code: { type: String, required: true, unique: true },
    name: { type: String, required: true },
    type: { type: String, enum: ['warehouse', 'store', 'bin'], default: 'warehouse' },
    address: { type: String }
  },
  { timestamps: true }
);

const Location = mongoose.model('Location', LocationSchema);
module.exports = Location;


