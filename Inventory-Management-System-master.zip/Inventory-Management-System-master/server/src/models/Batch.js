const mongoose = require('mongoose');

const BatchSchema = new mongoose.Schema(
  {
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
    location: { type: mongoose.Schema.Types.ObjectId, ref: 'Location', required: true },
    quantity: { type: Number, required: true, min: 0 },
    lotNumber: { type: String },
    expiryDate: { type: Date },
    costPerUnit: { type: Number, default: 0 }
  },
  { timestamps: true }
);

const Batch = mongoose.model('Batch', BatchSchema);
module.exports = Batch;


