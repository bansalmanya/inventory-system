const mongoose = require('mongoose');

const AlertSchema = new mongoose.Schema(
  {
    type: { type: String, enum: ['low_stock', 'expiry_soon'], required: true },
    item: { type: mongoose.Schema.Types.ObjectId, ref: 'Item', required: true },
    message: { type: String, required: true },
    resolved: { type: Boolean, default: false }
  },
  { timestamps: true }
);

const Alert = mongoose.model('Alert', AlertSchema);
module.exports = Alert;


