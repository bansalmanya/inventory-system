const mongoose = require('mongoose');

const ItemSchema = new mongoose.Schema(
  {
    sku: { type: String, required: true, unique: true, index: true },
    name: { type: String, required: true },
    description: { type: String },
    category: { type: String },
    unit: { type: String, default: 'pcs' },
    reorderPoint: { type: Number, default: 10 },
    targetStock: { type: Number, default: 50 },
    barcode: { type: String },
    qrCode: { type: String },
    attributes: { type: Map, of: String },
    tags: { type: [String], index: true, default: [] }
  },
  { timestamps: true }
);

const Item = mongoose.model('Item', ItemSchema);
module.exports = Item;


