const mongoose = require('mongoose');

const SupplierSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String },
    phone: { type: String },
    address: { type: String },
    leadTimeDays: { type: Number, default: 7 }
  },
  { timestamps: true }
);

const Supplier = mongoose.model('Supplier', SupplierSchema);
module.exports = Supplier;


