const bcrypt = require('bcryptjs');
const { connectToDatabase } = require('../src/utils/db');
const { loadConfig } = require('../src/utils/config');
const User = require('../src/models/User');
const Item = require('../src/models/Item');
const Location = require('../src/models/Location');
const Batch = require('../src/models/Batch');
const Transaction = require('../src/models/Transaction');
const Supplier = require('../src/models/Supplier');
const Alert = require('../src/models/Alert');

(async function () {
  const config = loadConfig();
  await connectToDatabase(config.MONGODB_URI);
  console.log('Seeding...');
  // Users
  const ensureUser = async (email, name, role, pass = 'admin123') => {
    const passwordHash = await bcrypt.hash(pass, 10);
    const updated = await User.findOneAndUpdate(
      { email },
      { $set: { name, role, passwordHash } },
      { upsert: true, new: true }
    );
    return updated;
  };
  await ensureUser('admin@example.com', 'Admin', 'admin');
  await ensureUser('manager@example.com', 'Manager', 'manager', 'manager123');
  await ensureUser('staff@example.com', 'Staff', 'staff', 'staff123');
  await ensureUser('viewer@example.com', 'Viewer', 'viewer', 'viewer123');
  // Locations
  const wh = await Location.findOneAndUpdate({ code: 'WH-1' }, { code: 'WH-1', name: 'Main Warehouse', type: 'warehouse' }, { upsert: true, new: true });
  const store = await Location.findOneAndUpdate({ code: 'ST-1' }, { code: 'ST-1', name: 'Downtown Store', type: 'store' }, { upsert: true, new: true });
  const binA = await Location.findOneAndUpdate({ code: 'BIN-A1' }, { code: 'BIN-A1', name: 'Bin A1', type: 'bin' }, { upsert: true, new: true });

  // Suppliers
  await Supplier.deleteMany({});
  const suppliers = await Supplier.insertMany([
    { name: 'Acme Supplies', email: 'sales@acme.test', phone: '+1 555 1000', leadTimeDays: 5 },
    { name: 'Green Foods Co', email: 'hello@greenfoods.test', phone: '+1 555 2000', leadTimeDays: 3 }
  ]);

  const itemsData = [
    { sku: 'SKU-001', name: 'USB-C Charger 30W', category: 'Electronics', reorderPoint: 10, targetStock: 60, description: 'Fast charger for phones and tablets', attributes: { brand: 'VoltMax' } },
    { sku: 'SKU-002', name: 'HDMI Cable 2m', category: 'Electronics', reorderPoint: 15, targetStock: 80, description: 'High speed HDMI 2.1 cable', attributes: { brand: 'CineLink' } },
    { sku: 'SKU-003', name: 'Glass Water Bottle 1L', category: 'Kitchen', reorderPoint: 8, targetStock: 40, description: 'Reusable fragile glass bottle', attributes: { color: 'clear' } },
    { sku: 'SKU-004', name: 'Hand Sanitizer 500ml', category: 'Consumable', reorderPoint: 12, targetStock: 100, description: 'Alcohol-based consumable sanitizer', attributes: { scent: 'neutral' } },
    { sku: 'SKU-005', name: 'Organic Milk 1L', category: 'Grocery', reorderPoint: 20, targetStock: 120, description: 'Perishable dairy product', attributes: { fat: '3.5%' } },
    { sku: 'SKU-006', name: 'Laptop Stand', category: 'Electronics', reorderPoint: 5, targetStock: 30, description: 'Aluminum ergonomic stand' }
  ];
  const items = [];
  for (const it of itemsData) {
    const doc = await Item.findOneAndUpdate({ sku: it.sku }, { $setOnInsert: it }, { upsert: true, new: true, setDefaultsOnInsert: true });
    items.push(doc);
  }

  // Clear demo inventory transactions for a clean reseed
  await Batch.deleteMany({});
  await Transaction.deleteMany({});

  const now = new Date();
  const addDays = (d) => new Date(now.getTime() + d * 86400000);
  const findItem = (sku) => items.find(i => i.sku === sku);

  await Batch.insertMany([
    { item: findItem('SKU-001')._id, location: wh._id, quantity: 40, lotNumber: 'L-CHG-1', costPerUnit: 6 },
    { item: findItem('SKU-002')._id, location: wh._id, quantity: 70, lotNumber: 'L-HDM-1', costPerUnit: 3 },
    { item: findItem('SKU-003')._id, location: wh._id, quantity: 25, lotNumber: 'L-GLS-1', costPerUnit: 4 },
    { item: findItem('SKU-004')._id, location: store._id, quantity: 60, lotNumber: 'L-SAN-1', costPerUnit: 2 },
    { item: findItem('SKU-005')._id, location: store._id, quantity: 80, lotNumber: 'L-MLK-1', expiryDate: addDays(7), costPerUnit: 1.2 },
    { item: findItem('SKU-006')._id, location: binA._id, quantity: 15, lotNumber: 'L-STN-1', costPerUnit: 9 }
  ]);

  // recent transactions
  const mkTx = async (type, sku, qty, fromLoc, toLoc, daysAgo) => {
    const item = findItem(sku);
    const createdAt = addDays(-daysAgo);
    await Transaction.create({ type, item: item._id, quantity: qty, fromLocation: fromLoc?._id, toLocation: toLoc?._id, createdAt });
  };
  await mkTx('out', 'SKU-001', 8, wh, null, 1);
  await mkTx('out', 'SKU-002', 12, wh, null, 2);
  await mkTx('transfer', 'SKU-003', 5, wh, store, 3);
  await mkTx('out', 'SKU-004', 15, store, null, 4);
  await mkTx('out', 'SKU-005', 20, store, null, 1);
  await mkTx('in', 'SKU-006', 10, null, binA, 2);

  // Generate alerts for low stock / expiry soon
  await Alert.deleteMany({});
  const itemsAll = await Item.find();
  for (const it of itemsAll) {
    const totalAgg = await Batch.aggregate([{ $match: { item: it._id } }, { $group: { _id: '$item', total: { $sum: '$quantity' } } }]);
    const total = totalAgg[0]?.total || 0;
    if (total <= it.reorderPoint) {
      await Alert.create({ type: 'low_stock', item: it._id, message: `${it.name} low: ${total} ≤ RP ${it.reorderPoint}` });
    }
  }
  const soon = new Date(Date.now() + 14 * 86400000);
  const expBatches = await Batch.find({ expiryDate: { $ne: null, $lte: soon } });
  for (const b of expBatches) {
    await Alert.create({ type: 'expiry_soon', item: b.item, message: `Batch ${b.lotNumber || ''} expiring ${b.expiryDate?.toISOString()?.slice(0,10)}` });
  }

  console.log('Seed complete.');
  process.exit(0);
})().catch((e) => { console.error(e); process.exit(1); });


